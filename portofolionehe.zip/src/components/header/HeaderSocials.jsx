import React from 'react'
import { BsLinkedin } from 'react-icons/bs';
import { GrInstagram } from 'react-icons/gr'
import { FaFacebookSquare } from 'react-icons/fa'

const HeaderSocials = () => {
  return (
    <div className='header__socials'>
      <a href="https://www.linkedin.com/in/nehemia-gueldi-774643236/" target="_blank"><BsLinkedin/></a>
      <a href="https://www.instagram.com/nehemiagueldi/" target="_blank"><GrInstagram/></a>
      <a href="https://www.facebook.com/nehemia.gueldigunawan.1" target="_blank"><FaFacebookSquare/></a>
    </div>
  )
}

export default HeaderSocials